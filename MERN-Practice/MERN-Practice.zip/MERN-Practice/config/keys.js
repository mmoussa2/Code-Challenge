module.exports = {
  mongoURI ='mongodb://<DBUser>:<password>@cluster.mongodb.net/test?retryWrites=true&w=majority'
}